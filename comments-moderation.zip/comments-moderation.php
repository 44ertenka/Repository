
 <?php
 
 $comments = get_comments(array(
      'post_id' => get_the_ID(),
      'status' => 'approve'
   ));
   
   
   $comments

?>